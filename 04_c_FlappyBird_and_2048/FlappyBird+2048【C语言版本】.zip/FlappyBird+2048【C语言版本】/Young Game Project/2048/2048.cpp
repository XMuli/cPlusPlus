﻿// 2048.cpp: 定义控制台应用程序的入口点。
//

#include "stdafx.h"
#include "fun.h"
#include <windows.h>


int main()
{
	StartGame(); 
	
    return 0;
}

